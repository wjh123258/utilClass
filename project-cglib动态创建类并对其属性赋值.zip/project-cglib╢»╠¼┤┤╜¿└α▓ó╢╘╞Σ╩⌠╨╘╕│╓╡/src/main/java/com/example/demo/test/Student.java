package com.example.demo.test;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2019/3/16 0016.
 */
public class Student extends Person {
    private  String socre;

    private ArrayList<String> books;

    public String getSocre() {
        return socre;
    }

    public void setSocre(String socre) {
        this.socre = socre;
    }

    public ArrayList<String> getBooks() {
        return books;
    }

    public void setBooks(ArrayList<String> books) {
        this.books = books;
    }
}
