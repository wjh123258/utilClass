package com.example.demo;

import com.example.demo.test.DynamicBean;
import com.example.demo.test.Student;

import sun.reflect.FieldInfo;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.*;

/**
 * Created by Administrator on 2019/3/16 0016.
 */
public class ReflectUtil {

    /**
     * 获取类对象
     * */
//    public static CtClass getClass(String name) throws NotFoundException {
//       ClassPool classPool = ClassPool.getDefault();
//
//       return  classPool.makeClass(name);
//    }

//    public static void addRemainFields(CtClass ctClass, Object targetObject, List<String> removeVariables) {
//        //获取目标对象所有字段
//        List<Field> allFields = getAllFields(targetObject);
//        //去除要移除的字段
//        if (removeVariables!=null){
//            allFields = deleteFields(allFields, removeVariables);
//        }
//
//        for (Field f: allFields){
////            CtField.make()
////            ctClass.addField();
//        }
//
//        return;



//    }

//    public static void addFields(CtClass ctClass, Object targetObject, List<String> addVariables) {
//
//    }

    /**
     * 获取当前对象所有字段
     * */
    public static List<Field>  getAllFields(Object targetObject){
        List<Field> fields =new ArrayList<>();
        Class<?> aClass = targetObject.getClass();
        while (aClass!=null){
            fields.addAll(Arrays.asList(aClass.getDeclaredFields()));
            aClass = aClass.getSuperclass();
        }
        return fields;
    }

    /**
     * 删除要移除的字段
     * */
    public static List<Field>  deleteFields(List<Field> fields,List<String> removeVariables){
        for (String vName:removeVariables){
            Iterator<Field> it = fields.iterator();
            while(it.hasNext()){
                Field x = it.next();
                if(x.getName().equals(vName)){
                    it.remove();
                }
            }
        }

        return fields;
    }

    /**
     * 放入字段名及类型到map
     * */
    public static void   putFieldToMap(Map typeMap,List<Field> fields){
        for (Field f : fields) {
            typeMap.put(f.getName(), f.getType());
        }
    }

    /**
     *给字段赋值
     * */
    public static void  setFieldValue(DynamicBean bean,Object object,List<Field> fieldList) throws IllegalAccessException {
        for (Field f : fieldList) {
            f.setAccessible(true);
            String name = f.getName();
            Object value = f.get(object);
            bean.setValue(name, value);
        }
    }

    public static void main(String[] args) throws  IllegalAccessException, InstantiationException {

        Student student = new Student();
        student.setSocre("109");
        student.setName("wjh");

        List<Field> allFields = getAllFields(student);




        HashMap typeMap = new HashMap();



        for (Field f: allFields){
            System.out.println("value:"+f.getName());
            System.out.println("type:"+f.getType().getSimpleName()+"::"+f.getGenericType().getTypeName());
            //CtField field = CtField.make("	public  "+f.getType().getSimpleName()+"  "+f.getName()+";", helloClass);

            typeMap.put(f.getName(),f.getType());



        }
        DynamicBean bean = new DynamicBean(typeMap);

        for (Field f: allFields){

            f.setAccessible(true);
            bean.setValue(f.getName(),f.get(student));

        }


        System.out.println(bean);
//        Object o = helloClass.toClass().newInstance();


    }
}
