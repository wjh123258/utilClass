package com.example.demo.controller;

import com.example.demo.test.DynamicBean;
import com.example.demo.test.Student;
import com.example.demo.test.User;
import org.springframework.util.MimeType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.jws.soap.SOAPBinding;
import java.awt.*;
import java.lang.reflect.Field;
import java.util.*;
import java.util.List;

import static com.example.demo.ReflectUtil.*;

/**
 * Created by Administrator on 2019/3/16 0016.
 */
@RestController
public class TestController {

    @GetMapping(value = "/test")
    public DynamicBean test() throws IllegalAccessException {

        Student student = new Student();
        student.setSocre("109");
        student.setAge(10);
        student.setName("wjh");
        ArrayList<String> objects = new ArrayList<>();
        objects.add("hhh");
        student.setBooks(objects);

        User user = new User();
        user.setUu("uuu111");
        user.setAge(100);
        user.setName("zzq");



        java.util.List<Field> allFields = getAllFields(student);
        List<String> remoList=new ArrayList<>();
        remoList.add("socre");
        allFields=deleteFields(allFields,remoList);

        java.util.List<Field> userAllFields = getAllFields(user);
        List<String> remoUserList=new ArrayList<>();
        remoUserList.add("uu");
        deleteFields(userAllFields,remoUserList);


        HashMap typeMap = new HashMap();

        putFieldToMap(typeMap,allFields);
        putFieldToMap(typeMap,userAllFields);

        DynamicBean bean = new DynamicBean(typeMap);

        setFieldValue(bean,student,allFields);
        setFieldValue(bean,user,userAllFields);

        return bean;
    }
}
