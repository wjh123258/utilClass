package com.example.demo.test;

public class User extends Person{

	private String uu;

	public String getUu() {
		return uu;
	}

	public void setUu(String uu) {
		this.uu = uu;
	}
}
